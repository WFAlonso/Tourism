﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface IDetailBookingRepository
    {
        Task<DetailBooking> GetByIdAsync(int id);
        Task<IEnumerable<FeactureBooking>> GetByIdBookingAsync(int id);
        Task AddAsync(DetailBooking hotel);
        Task<IEnumerable<DetailBooking>> GetAllAsync();
        Task UpdateAsync(DetailBooking reserva);
        Task DeleteAsync(int id);
    }
}
