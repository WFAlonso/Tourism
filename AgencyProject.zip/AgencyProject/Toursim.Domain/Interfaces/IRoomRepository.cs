﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface IRoomRepository
    {
        Task<Room> GetByIdAsync(int id);
        Task AddAsync(Room hotel);
        Task<IEnumerable<Room>> GetAllAsync();
        Task UpdateAsync(Room reserva);
        Task UpdateRoomAsync(Room roomBefore, Room roomNext);
        Task DeleteAsync(int id);
    }
}
