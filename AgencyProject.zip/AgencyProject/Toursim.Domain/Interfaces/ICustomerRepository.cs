﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface ICustomerRepository
    {
        Task<Customer> GetByIdAsync(int id);
        Task AddAsync(Customer hotel);
        Task<IEnumerable<Customer>> GetAllAsync();
        Task UpdateAsync(Customer reserva);
        Task DeleteAsync(int id);
    }
}
