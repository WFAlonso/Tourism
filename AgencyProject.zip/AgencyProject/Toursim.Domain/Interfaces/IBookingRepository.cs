﻿using Toursim.Domain.Entities;

namespace Toursim.Domain.Interfaces.Booking
{
    public interface IBookingRepository
    {
        Task<Entities.Booking> GetByIdAsync(int id);
        Task<IEnumerable<BookingDetail>> GetByIdHotelAsync(int idHotel);
       // Task<IEnumerable<Domain.Entities.Booking>> GetByIdHotelAsync(int idHotel);
        Task AddAsync(Entities.Booking booking);
        Task<IEnumerable<Entities.Booking>> GetAllAsync();
        Task UpdateAsync(Entities.Booking reserva);
        Task DeleteAsync(int id);
    }
}
