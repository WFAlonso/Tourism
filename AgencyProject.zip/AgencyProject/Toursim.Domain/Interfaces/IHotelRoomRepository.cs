﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface IHotelRoomRepository
    {
        Task<HotelRoom> GetByIdAsync(int id);
        Task AddAsync(HotelRoom hotel);
        Task<IEnumerable<HotelRoom>> GetAllAsync();
        Task UpdateAsync(HotelRoom reserva);
        Task DeleteAsync(int id);
    }
}
