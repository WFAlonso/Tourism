﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface ITypeCustomerRepository
    {
        Task<TypeCustomer> GetByIdAsync(int id);
        Task AddAsync(TypeCustomer hotel);
        Task<IEnumerable<TypeCustomer>> GetAllAsync();
        Task UpdateAsync(TypeCustomer reserva);
        Task DeleteAsync(int id);
    }
}
