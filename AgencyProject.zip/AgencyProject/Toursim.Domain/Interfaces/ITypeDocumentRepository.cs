﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface ITypeDocumentRepository
    {
        Task<TypeDocument> GetByIdAsync(int id);
        Task AddAsync(TypeDocument hotel);
        Task<IEnumerable<TypeDocument>> GetAllAsync();
        Task UpdateAsync(TypeDocument reserva);
        Task DeleteAsync(int id);
    }
}
