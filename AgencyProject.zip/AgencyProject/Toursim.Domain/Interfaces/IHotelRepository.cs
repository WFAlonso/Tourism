﻿using Toursim.Domain.Entities;
using System.Threading.Tasks;

namespace Toursim.Domain.Interfaces
{
    public interface IHotelRepository
    {
        Task<Hotel> GetByIdAsync(int id);
        Task AddAsync(Hotel hotel);
        Task<IEnumerable<Hotel>> GetAllAsync(bool? find);
        Task<IEnumerable<Domain.Entities.Hotel>> GetHotelsByStateAsync(bool active);
        Task UpdateAsync(Hotel reserva);
        Task DeleteAsync(int id);
        Task<IEnumerable<Domain.Entities.Hotel>> GetHotelByFilter(FilterHotel filter);
    }
}
