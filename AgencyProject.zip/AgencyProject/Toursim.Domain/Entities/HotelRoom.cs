﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Domain.Entities
{
    public class HotelRoom
    {
        public int IdHotelRoom { get; set; }

        public int IdHotel { get; set; }

        public int IdRoom { get; set; }

        public decimal Amount { get; set; }

        public bool Active { get; set; }

        public virtual ICollection<DetailBooking> DetailBookings { get; set; } = new List<DetailBooking>();
    }
}
