﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Domain.Entities
{
    public class FeactureBooking
    {
        public int IdDetail { get; set; }
        public int BookingId { get; set; }
        public int IdHotelRoom { get; set; }      
        public int IdCustomer { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public int IdTypeCustomer { get; set; }
        public string TypeCustomer { get; set; } = string.Empty;
    }
}
