﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Domain.Entities
{
    public class FilterHotel
    {
        public DateTime InDate { get; set; }
        public DateTime OutDate { get; set; } 
        public string CountRooms { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
    }
}
