﻿
namespace Toursim.Domain.Entities
{
    public class BookingDetail
    {
        public int BookingId { get; set; }
        public int IdHotel { get; set; }
        public string HotelName { get; set; } = string.Empty;
        public int GuestsNumber { get; set; }
        public int IdCustomer { get; set; }        
        public string CustomerName { get; set; } = string.Empty;
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
        public int TypeCustomer { get; set; }

    }
}
