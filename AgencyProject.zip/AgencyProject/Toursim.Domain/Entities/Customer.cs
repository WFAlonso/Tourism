﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Domain.Entities
{
    public class Customer
    {
        public int IdCustomer { get; set; }

        public int TypeDocument { get; set; }

        public decimal NumDocument { get; set; }

        public string Name { get; set; }

        public string Lastname { get; set; }

        public DateTime? Birthday { get; set; }

        public string Gender { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public int TypeCustomer { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

        public virtual ICollection<DetailBooking> DetailBookings { get; set; } = new List<DetailBooking>();

        public virtual TypeCustomer TypeCustomerNavigation { get; set; }

        public virtual TypeDocument TypeDocumentNavigation { get; set; }
    }
}
