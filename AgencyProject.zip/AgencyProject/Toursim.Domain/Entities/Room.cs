﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Toursim.Domain.Entities
{
    public class  Room
    {
        public int IdRoom { get; set; }

        public string TypeRoom { get; set; }

        public int MinPerson { get; set; }

        public int MaxPerson { get; set; }

        public bool Active { get; set; }

        public void UpdateDetails(Room roomModel)
        {
            if (roomModel == null)
            {
                throw new ArgumentNullException(nameof(roomModel), "El modelo de habitación no puede ser nulo.");
            }
            IdRoom = roomModel.IdRoom;
            TypeRoom = roomModel.TypeRoom;
            MinPerson = roomModel.MinPerson;
            MaxPerson = roomModel.MaxPerson;
            Active = roomModel.Active;
        }
    }
}
