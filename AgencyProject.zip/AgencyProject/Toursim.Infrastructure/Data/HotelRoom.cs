﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class HotelRoom
{
    public int IdHotelRoom { get; set; }

    public int IdHotel { get; set; }

    public int IdRoom { get; set; }

    public decimal Amount { get; set; }

    public bool Active { get; set; }

    public virtual ICollection<DetailBooking> DetailBookings { get; set; } = new List<DetailBooking>();

    public virtual Room IdRoomNavigation { get; set; }
}
