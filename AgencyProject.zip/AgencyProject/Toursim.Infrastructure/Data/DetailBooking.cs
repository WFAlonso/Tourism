﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class DetailBooking
{
    public int IdDetail { get; set; }

    public int IdBooking { get; set; }

    public int IdHotelRoom { get; set; }

    public int IdCustomer { get; set; }

    public int TypeCustomer { get; set; }

    public virtual Booking IdBookingNavigation { get; set; }

    public virtual Customer IdCustomerNavigation { get; set; }

    public virtual HotelRoom IdHotelRoomNavigation { get; set; }

    public virtual TypeCustomer TypeCustomerNavigation { get; set; }
}
