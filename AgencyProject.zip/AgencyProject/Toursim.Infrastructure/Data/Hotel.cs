﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class Hotel
{
    public int IdHotel { get; set; }

    public string Name { get; set; }

    public string City { get; set; }

    public int Commission { get; set; }

    public bool Favorite { get; set; }

    public bool Active { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
}
