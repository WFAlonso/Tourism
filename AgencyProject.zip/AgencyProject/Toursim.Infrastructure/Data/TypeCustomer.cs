﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class TypeCustomer
{
    public int TypeCustomer1 { get; set; }

    public string NameCustomer { get; set; }

    public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    public virtual ICollection<DetailBooking> DetailBookings { get; set; } = new List<DetailBooking>();
}
