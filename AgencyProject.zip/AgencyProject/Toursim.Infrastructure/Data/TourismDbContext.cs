﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Toursim.Infrastructure.Data;

public partial class TourismDbContext : DbContext
{
    public TourismDbContext()
    {
    }

    public TourismDbContext(DbContextOptions<TourismDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<DetailBooking> DetailBookings { get; set; }

    public virtual DbSet<Hotel> Hotels { get; set; }

    public virtual DbSet<HotelRoom> HotelRooms { get; set; }

    public virtual DbSet<Room> Rooms { get; set; }

    public virtual DbSet<TypeCustomer> TypeCustomers { get; set; }

    public virtual DbSet<TypeDocument> TypeDocuments { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.IdBooking).HasName("PK_Reserva");

            entity.ToTable("Booking");

            entity.Property(e => e.IdBooking).ValueGeneratedNever();
            entity.Property(e => e.Amount).HasColumnType("numeric(18, 2)");
            entity.Property(e => e.DateEnd).HasColumnType("date");
            entity.Property(e => e.DateInicial).HasColumnType("date");
            entity.Property(e => e.Status)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.IdCustomerNavigation).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.IdCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Booking_Customer");

            entity.HasOne(d => d.IdHotelNavigation).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.IdHotel)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Booking_Hotel");

            entity.HasOne(d => d.TypeCustomerNavigation).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.TypeCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Booking_TypeCustomer");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.IdCustomer).HasName("PK_Customer_1");

            entity.ToTable("Customer");

            entity.HasIndex(e => new { e.TypeDocument, e.NumDocument }, "IX_Customer").IsUnique();

            entity.Property(e => e.IdCustomer).ValueGeneratedNever();
            entity.Property(e => e.Birthday).HasColumnType("date");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Lastname)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.NumDocument).HasColumnType("numeric(12, 0)");
            entity.Property(e => e.Phone)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.HasOne(d => d.TypeDocumentNavigation).WithMany(p => p.Customers)
                .HasForeignKey(d => d.TypeDocument)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Customer_TypeDocument");
        });

        modelBuilder.Entity<DetailBooking>(entity =>
        {
            entity.HasKey(e => e.IdDetail);

            entity.ToTable("DetailBooking");

            entity.Property(e => e.IdDetail).ValueGeneratedNever();

            entity.HasOne(d => d.IdBookingNavigation).WithMany(p => p.DetailBookings)
                .HasForeignKey(d => d.IdBooking)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DetailBooking_Booking");

            entity.HasOne(d => d.IdCustomerNavigation).WithMany(p => p.DetailBookings)
                .HasForeignKey(d => d.IdCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DetailBooking_Customer");

            entity.HasOne(d => d.IdHotelRoomNavigation).WithMany(p => p.DetailBookings)
                .HasForeignKey(d => d.IdHotelRoom)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DetailBooking_HotelRoom");

            entity.HasOne(d => d.TypeCustomerNavigation).WithMany(p => p.DetailBookings)
                .HasForeignKey(d => d.TypeCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DetailBooking_TypeCustomer");
        });

        modelBuilder.Entity<Hotel>(entity =>
        {
            entity.HasKey(e => e.IdHotel).HasName("PK_Hoteles");

            entity.ToTable("Hotel");

            entity.Property(e => e.IdHotel).ValueGeneratedNever();
            entity.Property(e => e.City)
                .IsRequired()
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<HotelRoom>(entity =>
        {
            entity.HasKey(e => e.IdHotelRoom);

            entity.ToTable("HotelRoom");

            entity.HasIndex(e => new { e.IdHotel, e.IdRoom }, "IX_HotelRoom").IsUnique();

            entity.Property(e => e.Amount).HasColumnType("numeric(18, 2)");

            entity.HasOne(d => d.IdRoomNavigation).WithMany(p => p.HotelRooms)
                .HasForeignKey(d => d.IdRoom)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_HotelRoom_HotelRoom");
        });

        modelBuilder.Entity<Room>(entity =>
        {
            entity.HasKey(e => e.IdRoom);

            entity.ToTable("Room");

            entity.Property(e => e.IdRoom).ValueGeneratedNever();
            entity.Property(e => e.TypeRoom)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TypeCustomer>(entity =>
        {
            entity.HasKey(e => e.TypeCustomer1);

            entity.ToTable("TypeCustomer");

            entity.Property(e => e.TypeCustomer1).HasColumnName("TypeCustomer");
            entity.Property(e => e.NameCustomer)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TypeDocument>(entity =>
        {
            entity.HasKey(e => e.TypeDocument1);

            entity.ToTable("TypeDocument");

            entity.Property(e => e.TypeDocument1).HasColumnName("TypeDocument");
            entity.Property(e => e.NameDocument)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
