﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class TypeDocument
{
    public int TypeDocument1 { get; set; }

    public string NameDocument { get; set; }

    public virtual ICollection<Customer> Customers { get; set; } = new List<Customer>();
}
