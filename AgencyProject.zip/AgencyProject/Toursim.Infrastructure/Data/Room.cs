﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class Room
{
    public int IdRoom { get; set; }

    public string TypeRoom { get; set; }

    public int MinPerson { get; set; }

    public int MaxPerson { get; set; }

    public bool Active { get; set; }

    public virtual ICollection<HotelRoom> HotelRooms { get; set; } = new List<HotelRoom>();
}
