﻿using System;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Data;

public partial class Booking
{
    public int IdBooking { get; set; }

    public int IdCustomer { get; set; }

    public int IdHotel { get; set; }

    public decimal Amount { get; set; }

    public int TotalPerson { get; set; }

    public DateTime DateInicial { get; set; }

    public DateTime DateEnd { get; set; }

    public string Status { get; set; }

    public int TypeCustomer { get; set; }

    public virtual ICollection<DetailBooking> DetailBookings { get; set; } = new List<DetailBooking>();

    public virtual Customer IdCustomerNavigation { get; set; }

    public virtual Hotel IdHotelNavigation { get; set; }

    public virtual TypeCustomer TypeCustomerNavigation { get; set; }
}
