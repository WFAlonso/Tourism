﻿using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using Toursim.Domain.Interfaces.Booking;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Linq;
using Toursim.Domain.Entities;
using System;

namespace Toursim.Infrastructure.Repositories
{
    public class BookingRepository  : IBookingRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public BookingRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.Booking> GetByIdAsync(int id)
        {
            var entities = await _context.Bookings.FindAsync(id);
            return _mapper.Map<Domain.Entities.Booking>(entities);
        }
    
        public async Task<IEnumerable<BookingDetail>> GetByIdHotelAsync(int idHotel)
        {
            var bookings = await _context.Bookings
                        .Where(b => b.IdHotel == idHotel)
                        .Include(b => b.DetailBookings)
                        .Include(b => b.IdCustomerNavigation)
                        .Include(b => b.IdHotelNavigation)
                        .Include(b => b.TypeCustomerNavigation)
                        .Select(b => new BookingDetail
                        {
                            BookingId = b.IdBooking,
                            IdHotel = b.IdHotel,
                            HotelName = b.IdHotelNavigation.Name,
                            IdCustomer = b.IdCustomer,
                            CustomerName = b.IdCustomerNavigation.Name,
                            GuestsNumber = b.TotalPerson,
                            CheckInDate = b.DateInicial,
                            CheckOutDate = b.DateEnd,
                            Amount = b.Amount,
                            Status = b.Status,
                            TypeCustomer = b.TypeCustomer
                        })
                        .ToListAsync();

            return bookings;
        }

        public async Task<IEnumerable<Domain.Entities.Booking>> GetAllAsync()
        {
            var entities = await _context.Bookings.ToListAsync();
            return _mapper.Map<IEnumerable<Domain.Entities.Booking>>(entities);

        }

        public async Task AddAsync(Domain.Entities.Booking reserva)
        {
            await _context.Bookings.AddAsync(_mapper.Map<Data.Booking>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Domain.Entities.Booking reserva)
        {
            _context.Bookings.Update(_mapper.Map<Data.Booking>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.Bookings.Remove(_mapper.Map<Data.Booking>(reserva));
                await _context.SaveChangesAsync();
            }
        }
    }
}