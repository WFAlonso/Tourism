﻿using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Repositories
{
    public class TypeCustomerRepository  : ITypeCustomerRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public TypeCustomerRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.TypeCustomer> GetByIdAsync(int id)
        {
            var entities = await _context.TypeCustomers.FindAsync(id);
            return _mapper.Map<Domain.Entities.TypeCustomer>(entities);
        }

        public async Task AddAsync(Domain.Entities.TypeCustomer TypeCustomer)
        {
            await _context.TypeCustomers.AddAsync(_mapper.Map<Data.TypeCustomer>(TypeCustomer));
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Domain.Entities.TypeCustomer>> GetAllAsync()
        {
            var entities = await _context.Bookings.ToListAsync();
            return _mapper.Map<IEnumerable<Domain.Entities.TypeCustomer>>(entities);

        }

        public async Task UpdateAsync(Domain.Entities.TypeCustomer reserva)
        {
            _context.TypeCustomers.Update(_mapper.Map<Data.TypeCustomer>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.TypeCustomers.Remove(_mapper.Map<Data.TypeCustomer>(reserva));
                await _context.SaveChangesAsync();
            }
        }
    }
}
