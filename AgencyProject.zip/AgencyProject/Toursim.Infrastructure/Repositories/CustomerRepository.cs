﻿using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public CustomerRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.Customer> GetByIdAsync(int id)
        {
            var entities = await _context.Customers.FindAsync(id);
            return _mapper.Map<Domain.Entities.Customer>(entities);
        }

        public async Task AddAsync(Domain.Entities.Customer hotel)
        {
            await _context.Customers.AddAsync(_mapper.Map<Data.Customer>(hotel));
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Domain.Entities.Customer>> GetAllAsync()
        {
            var entities = await _context.Customers.ToListAsync();
            return _mapper.Map<IEnumerable<Domain.Entities.Customer>>(entities);

        }

        public async Task UpdateAsync(Domain.Entities.Customer reserva)
        {
            _context.Customers.Update(_mapper.Map<Data.Customer>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.Customers.Remove(_mapper.Map<Data.Customer>(reserva));
                await _context.SaveChangesAsync();
            }
        }
    }
}
