﻿using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Collections.Generic;

namespace Toursim.Infrastructure.Repositories
{
    public class TypeDocumentRepository  : ITypeDocumentRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public TypeDocumentRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.TypeDocument> GetByIdAsync(int id)
        {
            var entities = await _context.TypeDocuments.FindAsync(id);
            return _mapper.Map<Domain.Entities.TypeDocument>(entities);
        }

        public async Task AddAsync(Domain.Entities.TypeDocument TypeDocument)
        {
            await _context.TypeDocuments.AddAsync(_mapper.Map<Data.TypeDocument>(TypeDocument));
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Domain.Entities.TypeDocument>> GetAllAsync()
        {
            var entities = await _context.Bookings.ToListAsync();
            return _mapper.Map<IEnumerable<Domain.Entities.TypeDocument>>(entities);

        }

        public async Task UpdateAsync(Domain.Entities.TypeDocument reserva)
        {
            _context.TypeDocuments.Update(_mapper.Map<Data.TypeDocument>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.TypeDocuments.Remove(_mapper.Map<Data.TypeDocument>(reserva));
                await _context.SaveChangesAsync();
            }
        }
    }
}
