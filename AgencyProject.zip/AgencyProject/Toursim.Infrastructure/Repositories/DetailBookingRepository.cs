﻿using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Collections.Generic;
using System.Linq;

namespace Toursim.Infrastructure.Repositories
{
    public class DetailBookingRepository : IDetailBookingRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public DetailBookingRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.DetailBooking> GetByIdAsync(int id)
        {
            var entities = await _context.DetailBookings.FindAsync(id);
            return _mapper.Map<Domain.Entities.DetailBooking>(entities);
        }

        public async Task<IEnumerable<Domain.Entities.FeactureBooking>> GetByIdBookingAsync(int id)
        {
            var DetailBookings = await _context.DetailBookings
                        .Where(b => b.IdBooking == id)
                        .Include(b => b.IdCustomerNavigation)
                        .Include(b => b.IdBookingNavigation)
                        .Include(b => b.IdHotelRoomNavigation)
                        .Include(b => b.TypeCustomerNavigation)
                        .Select(b => new FeactureBooking
                        {
                            IdDetail = b.IdDetail,
                            BookingId = b.IdBooking,
                            IdHotelRoom = b.IdHotelRoomNavigation.IdRoom,
                            IdCustomer = b.IdCustomer,
                            CustomerName = b.IdCustomerNavigation.Name,
                            IdTypeCustomer = b.TypeCustomer,
                            TypeCustomer = b.TypeCustomerNavigation.NameCustomer
                        })
                        .ToListAsync();

            return DetailBookings;
        }

        public async Task AddAsync(Domain.Entities.DetailBooking DetailBooking)
        {
            await _context.DetailBookings.AddAsync(_mapper.Map<Data.DetailBooking>(DetailBooking));
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Domain.Entities.DetailBooking>> GetAllAsync()
        {
            var entities = await _context.Bookings.ToListAsync();
            return _mapper.Map<IEnumerable<Domain.Entities.DetailBooking>>(entities);

        }

        public async Task UpdateAsync(Domain.Entities.DetailBooking reserva)
        {
            _context.DetailBookings.Update(_mapper.Map<Data.DetailBooking>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.DetailBookings.Remove(_mapper.Map<Data.DetailBooking>(reserva));
                await _context.SaveChangesAsync();
            }
        }
    }
}
