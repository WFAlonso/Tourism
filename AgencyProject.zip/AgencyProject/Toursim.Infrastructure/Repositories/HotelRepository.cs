﻿using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Toursim.Infrastructure.Repositories
{
    public class HotelRepository : IHotelRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public HotelRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.Hotel> GetByIdAsync(int id)
        {
            var entities = await _context.Hotels.FindAsync(id);
            return _mapper.Map<Domain.Entities.Hotel>(entities);
        }

        public async Task AddAsync(Domain.Entities.Hotel hotel)
        {
            await _context.Hotels.AddAsync(_mapper.Map<Data.Hotel>(hotel));
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Domain.Entities.Hotel>> GetAllAsync(bool? favorite)
        {
            List<Data.Hotel> hotelList = new();
            if(favorite.HasValue)
                hotelList = await _context.Hotels.Where(h => h.Favorite.Equals(favorite))
                    .OrderByDescending(h => h.Commission)
                    .ToListAsync();
            else
                hotelList = await _context.Hotels.OrderByDescending(h => h.Favorite)
                    .OrderByDescending(h => h.Commission)
                    .ToListAsync();

            return _mapper.Map<IEnumerable<Domain.Entities.Hotel>>(hotelList);

        }

        public async Task<IEnumerable<Domain.Entities.Hotel>> GetHotelsByStateAsync(bool active)
        {
            List<Data.Hotel> hotelList = await _context.Hotels.Where(h => h.Active.Equals(active))
                    .OrderByDescending(h => h.Commission)
                    .ToListAsync();

            return _mapper.Map<IEnumerable<Domain.Entities.Hotel>>(hotelList);

        }

        public async Task UpdateAsync(Domain.Entities.Hotel reserva)
        {
            _context.Hotels.Update(_mapper.Map<Data.Hotel>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.Hotels.Remove(_mapper.Map<Data.Hotel>(reserva));
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Domain.Entities.Hotel>> GetHotelByFilter(FilterHotel filter)
        {
            List<Data.Hotel> hotelList = new();

            hotelList = await _context.DetailBookings
                        .Include(b => b.IdCustomerNavigation)
                        .Include(b => b.IdBookingNavigation)
                        .Include(b => b.IdHotelRoomNavigation)
                        .Include(b => b.IdHotelRoomNavigation.IdRoomNavigation)
                        .Include(b => b.IdBookingNavigation.IdHotelNavigation)        

                        .Where(b => b.IdBookingNavigation.IdHotelNavigation.City == filter.City)
                        .Where(b => b.IdBookingNavigation.DateInicial != filter.InDate)
                        .Where(b => b.IdBookingNavigation.DateEnd != filter.OutDate)
                        .Select(b => new Data.Hotel
                        {
                            IdHotel = b.IdBookingNavigation.IdHotelNavigation.IdHotel,
                            City = b.IdBookingNavigation.IdHotelNavigation.City,
                            Name = b.IdBookingNavigation.IdHotelNavigation.Name,
                            Commission = b.IdBookingNavigation.IdHotelNavigation.Commission,
                            Favorite = b.IdBookingNavigation.IdHotelNavigation.Favorite,
                            Active = b.IdBookingNavigation.IdHotelNavigation.Active
                        })
                        .Distinct()
                        .ToListAsync();

            return _mapper.Map<IEnumerable<Domain.Entities.Hotel>>(hotelList);
        }
    }
}
