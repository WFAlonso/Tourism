﻿using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Toursim.Infrastructure.Data;
using AutoMapper;
using System.Collections.Generic;
using System;
using System.Linq;

namespace Toursim.Infrastructure.Repositories
{
    public class RoomRepository : IRoomRepository
    {
        private readonly TourismDbContext _context;
        private readonly IMapper _mapper;

        public RoomRepository(TourismDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.Room> GetByIdAsync(int id)
        {
            var entities = await _context.Rooms.FindAsync(id);
            if (entities is not null) 
                _context.Entry(entities).State = EntityState.Detached;
            return _mapper.Map<Domain.Entities.Room>(entities);
        }

        public async Task AddAsync(Domain.Entities.Room Room)
        {
            await _context.Rooms.AddAsync(_mapper.Map<Data.Room>(Room));
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Domain.Entities.Room>> GetAllAsync()
        {
            var entities = await _context.Bookings.ToListAsync();
            return _mapper.Map<IEnumerable<Domain.Entities.Room>>(entities);

        }

        public async Task UpdateAsync(Domain.Entities.Room reserva)
        {
            _context.Rooms.Update(_mapper.Map<Data.Room>(reserva));
            await _context.SaveChangesAsync();
        }

        public async Task UpdateRoomAsync(Domain.Entities.Room roomBefore, Domain.Entities.Room roomNext)
        {
            var entities = _mapper.Map<Data.Room>(roomBefore);
            _context.Entry(entities).CurrentValues.SetValues(_mapper.Map<Data.Room>(roomNext));
            _context.Entry(entities).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var reserva = await GetByIdAsync(id);
            if (reserva != null)
            {
                _context.Rooms.Remove(_mapper.Map<Data.Room>(reserva));
                await _context.SaveChangesAsync();
            }
        }
    }
}
