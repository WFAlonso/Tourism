﻿using AutoMapper;
using Toursim.Domain.Entities;
using Toursim.Infrastructure.Data;

namespace Toursim.Infrastructure.Mappings
{
    public class InfraestructureMappingProfile : Profile
    {
        public InfraestructureMappingProfile()
        {
            CreateMap<Domain.Entities.Booking, Data.Booking>();
            CreateMap<Data.Booking, Domain.Entities.Booking>();
            CreateMap<Domain.Entities.Customer, Data.Customer>();
            CreateMap<Data.Customer, Domain.Entities.Customer>();
            CreateMap<Domain.Entities.DetailBooking, Data.DetailBooking>();
            CreateMap<Data.DetailBooking, Domain.Entities.DetailBooking>();
            CreateMap<Domain.Entities.Hotel, Data.Hotel>();
            CreateMap<Data.Hotel, Domain.Entities.Hotel>();
            CreateMap<Domain.Entities.HotelRoom, Data.HotelRoom>();
            CreateMap<Data.HotelRoom, Domain.Entities.HotelRoom>();
            CreateMap<Domain.Entities.Room, Data.Room>();
            CreateMap<Data.Room, Domain.Entities.Room>();
            CreateMap<Domain.Entities.TypeCustomer, Data.TypeCustomer>();
            CreateMap<Data.TypeCustomer, Domain.Entities.TypeCustomer>();
            CreateMap<Domain.Entities.TypeDocument, Data.TypeDocument>();
            CreateMap<Data.TypeDocument, Domain.Entities.TypeDocument>();
        }
    }
}
