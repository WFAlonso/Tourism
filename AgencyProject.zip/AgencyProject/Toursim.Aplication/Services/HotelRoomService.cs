﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Infrastructure.Repositories;

namespace Toursim.Application.Services
{
    public class HotelRoomService : IHotelRoomService
    {
        private readonly IHotelRoomRepository _HotelRoomRepository;
        private readonly IMapper _mapper;

        public HotelRoomService(IHotelRoomRepository HotelRoomRepository, IMapper mapper)
        {
            _HotelRoomRepository = HotelRoomRepository;
            _mapper = mapper;
        }

        public async Task<HotelRoomModel> GetHotelRoomAsync(int id)
        {
            HotelRoom respuesta = new();
            respuesta = await _HotelRoomRepository.GetByIdAsync(id);
            return _mapper.Map<HotelRoomModel>(respuesta);
        }

        public async Task<HotelRoomModel> CreateHotelRoomAsync(HotelRoomModel HotelRoomDto)
        {
            HotelRoom respuesta = new();
            respuesta = _mapper.Map<HotelRoom>(HotelRoomDto);
            await _HotelRoomRepository.AddAsync(respuesta);
            return _mapper.Map<HotelRoomModel>(respuesta);
        }

        public async Task<IEnumerable<HotelRoomModel>> GetAllHotelRooms()
        {
            var list = await _HotelRoomRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<HotelRoomModel>>(list);
        }

        public async Task<HotelRoomModel> UpdateHotelRoom(int id, HotelRoomModel param)
        {
            Domain.Entities.HotelRoom respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.HotelRoom>(param);
            respuesta.IdHotelRoom = id;
            await _HotelRoomRepository.UpdateAsync(respuesta);
            return _mapper.Map<HotelRoomModel>(respuesta);
        }

        public void DeleteHotelRoom(int id)
        {
            _HotelRoomRepository.DeleteAsync(id);
        }
    }
}
