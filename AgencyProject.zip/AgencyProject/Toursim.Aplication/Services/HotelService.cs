﻿using AutoMapper;
using System.Reflection.Metadata;
using System;
using Toursim.Application;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Interfaces;

namespace Toursim.Application.Services
{
	public class HotelService : IHotelService
	{
		private readonly IHotelRepository _hotelRepository;
		private readonly IMapper _mapper;

		public HotelService(IHotelRepository hotelRepository, IMapper mapper)
		{
			_hotelRepository = hotelRepository;
			_mapper = mapper;
		}

		public async Task<HotelModel> GetHotelAsync(int id)
		{
			Domain.Entities.Hotel respuesta = new();
			respuesta = await _hotelRepository.GetByIdAsync(id);
			return _mapper.Map<HotelModel>(respuesta);
		}

		public async Task<HotelModel> CreateHotelAsync(HotelModel hotelDto)
		{
			Domain.Entities.Hotel respuesta = new();
			respuesta = _mapper.Map<Domain.Entities.Hotel>(hotelDto);
			await _hotelRepository.AddAsync(respuesta);
			return _mapper.Map<HotelModel>(respuesta);
		}

		public async Task<IEnumerable<HotelModel>> GetAllHotels(TypeRegister type)
		{
			bool? top = type switch
            {
                TypeRegister.All => null,
                TypeRegister.Top => true,
                TypeRegister.NoTop => false,
                _ => null 
            };

            var list = await _hotelRepository.GetAllAsync(top);
			return _mapper.Map<IEnumerable<HotelModel>>(list);
		}

        public async Task<IEnumerable<HotelModel>> GetHotelsByStateAsync(bool state)
        {
            var list = await _hotelRepository.GetHotelsByStateAsync(state);
            return _mapper.Map<IEnumerable<HotelModel>>(list);
        }

        public async Task<HotelModel> UpdateHotel(HotelModel param)
		{
			Domain.Entities.Hotel respuesta = new();
			respuesta = _mapper.Map<Domain.Entities.Hotel>(param);
			await _hotelRepository.UpdateAsync(respuesta);
			return _mapper.Map<HotelModel>(respuesta); 
		}

		public void DeleteHotel(int id)
		{
			_hotelRepository.DeleteAsync(id);
		}

		public async Task<IEnumerable<HotelModel>> GetHotelByFilter(FilterHotelModel filter)
		{
            if (!DateTime.TryParse(filter.InDate, out DateTime inDate))
            {
                throw new ArgumentException("The format date is bad!.", nameof(filter.InDate));
            }
            if (!DateTime.TryParse(filter.OutDate, out DateTime outDate))
            {
                throw new ArgumentException("The format date is bad!.", nameof(filter.OutDate));
            }

			Domain.Entities.FilterHotel search = new()
			{
				OutDate = outDate,
				InDate= inDate,
				City= filter.City,
				CountRooms = filter.CountRooms
			};
            var list = await _hotelRepository.GetHotelByFilter(search);
            return _mapper.Map<IEnumerable<HotelModel>>(list);
        }
	}
}
