﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Toursim.Infrastructure.Data;

namespace Toursim.Application.Services
{
    public class RoomService : IRoomService
    {
        private readonly IRoomRepository _RoomRepository;
        private readonly IMapper _mapper;

        public RoomService(IRoomRepository RoomRepository, IMapper mapper)
        {
            _RoomRepository = RoomRepository;
            _mapper = mapper;
        }

        public async Task<RoomModel> GetRoomAsync(int id)
        {
            Domain.Entities.Room respuesta = new();
            respuesta = await _RoomRepository.GetByIdAsync(id);
            return _mapper.Map<RoomModel>(respuesta);
        }

        public async Task<RoomModel> CreateRoomAsync(RoomModel RoomDto)
        {
            Domain.Entities.Room respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.Room>(RoomDto);
            await _RoomRepository.AddAsync(respuesta);
            return _mapper.Map<RoomModel>(respuesta);
        }

        public async Task<IEnumerable<RoomModel>> GetAllRooms()
        {
            var list = await _RoomRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<RoomModel>>(list);
        }

        public async Task<RoomModel> UpdateRoom(RoomModel param)
        {
            Domain.Entities.Room respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.Room>(param);
            var existingRoom = await _RoomRepository.GetByIdAsync(param.IdRoom);

            if (existingRoom == null)
            {
                throw new KeyNotFoundException("Room No found.");
            }

            await _RoomRepository.UpdateRoomAsync(existingRoom, respuesta);
            return param;
        }

        public void DeleteRoom(int id)
        {
            _RoomRepository.DeleteAsync(id);
        }
    }
}
