﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Infrastructure.Repositories;

namespace Toursim.Application.Services
{
    public class TypeCustomerService : ITypeCustomerService
    {
        private readonly ITypeCustomerRepository _TypeCustomerRepository;
        private readonly IMapper _mapper;

        public TypeCustomerService(ITypeCustomerRepository TypeCustomerRepository, IMapper mapper)
        {
            _TypeCustomerRepository = TypeCustomerRepository;
            _mapper = mapper;
        }

        public async Task<TypeCustomerModel> GetTypeCustomerAsync(int id)
        {
            TypeCustomer respuesta = new();
            respuesta = await _TypeCustomerRepository.GetByIdAsync(id);
            return _mapper.Map<TypeCustomerModel>(respuesta);
        }

        public async Task<TypeCustomerModel> CreateTypeCustomerAsync(TypeCustomerModel TypeCustomerDto)
        {
            TypeCustomer respuesta = new();
            respuesta = _mapper.Map<TypeCustomer>(TypeCustomerDto);
            await _TypeCustomerRepository.AddAsync(respuesta);
            return _mapper.Map<TypeCustomerModel>(respuesta);
        }

        public async Task<IEnumerable<TypeCustomerModel>> GetAllTypeCustomers()
        {
            var list = await _TypeCustomerRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<TypeCustomerModel>>(list);
        }

        public async Task<TypeCustomerModel> UpdateTypeCustomer(TypeCustomerModel param)
        {
            Domain.Entities.TypeCustomer respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.TypeCustomer>(param);
            await _TypeCustomerRepository.UpdateAsync(respuesta);
            return _mapper.Map<TypeCustomerModel>(respuesta);
        }

        public void DeleteTypeCustomer(int id)
        {
            _TypeCustomerRepository.DeleteAsync(id);
        }
    }
}
