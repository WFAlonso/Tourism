﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Infrastructure.Repositories;
using Toursim.Domain.Interfaces.Booking;

namespace Toursim.Application.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IMapper _mapper;

        public CustomerService(ICustomerRepository customerRepository, IMapper mapper)
        {
            _customerRepository = customerRepository;
            _mapper = mapper;
        }

        public async Task<CustomerModel> GetCustomerAsync(int id)
        {
            Customer respuesta = new();
            respuesta = await _customerRepository.GetByIdAsync(id);
            return _mapper.Map<CustomerModel>(respuesta);
        }

        public async Task<CustomerModel> CreateCustomerAsync(CustomerModel hotelDto)
        {
            Customer respuesta = new();
            respuesta = _mapper.Map<Customer>(hotelDto);
            await _customerRepository.AddAsync(respuesta);
            return _mapper.Map<CustomerModel>(respuesta);
        }

        public async Task<IEnumerable<CustomerModel>> GetAllCustomers()
        {
            var list = await _customerRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<CustomerModel>>(list);
        }

        public async Task<CustomerModel> UpdateCustomerAsync(CustomerModel param)
        {
            Domain.Entities.Customer respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.Customer>(param);
            await _customerRepository.UpdateAsync(respuesta);
            return _mapper.Map<CustomerModel>(respuesta);
        }

        public void DeleteCustomer(int id)
        {
            _customerRepository.DeleteAsync(id);
        }
    }
}
