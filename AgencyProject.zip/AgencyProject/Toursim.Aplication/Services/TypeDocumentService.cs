﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Infrastructure.Repositories;

namespace Toursim.Application.Services
{
    public class TypeDocumentService : ITypeDocumentService
    {
        private readonly ITypeDocumentRepository _TypeDocumentRepository;
        private readonly IMapper _mapper;

        public TypeDocumentService(ITypeDocumentRepository typeDocumentRepository, IMapper mapper)
        {
            _TypeDocumentRepository = typeDocumentRepository;
            _mapper = mapper;
        }

        public async Task<TypeDocumentModel> GetTypeDocumentAsync(int id)
        {
            TypeDocument respuesta = new();
            respuesta = await _TypeDocumentRepository.GetByIdAsync(id);
            return _mapper.Map<TypeDocumentModel>(respuesta);
        }

        public async Task<TypeDocumentModel> CreateTypeDocumentAsync(TypeDocumentModel hotelDto)
        {
            TypeDocument respuesta = new();
            respuesta = _mapper.Map<TypeDocument>(hotelDto);
            await _TypeDocumentRepository.AddAsync(respuesta);
            return _mapper.Map<TypeDocumentModel>(respuesta);
        }

        public async Task<IEnumerable<TypeDocumentModel>> GetAllTypeDocuments()
        {
            var list = await _TypeDocumentRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<TypeDocumentModel>>(list);
        }

        public async Task<TypeDocumentModel> UpdateTypeDocument(TypeDocumentModel param)
        {
            Domain.Entities.TypeDocument respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.TypeDocument>(param);
            await _TypeDocumentRepository.UpdateAsync(respuesta);
            return _mapper.Map<TypeDocumentModel>(respuesta);
        }

        public void DeleteTypeDocument(int id)
        {
            _TypeDocumentRepository.DeleteAsync(id);
        }
    }
}
