﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Infrastructure.Repositories;
using System.Collections.Generic;

namespace Toursim.Application.Services
{
    public class DetailBookingService : IDetailBookingService
    {
        private readonly IDetailBookingRepository _DetailBookingRepository;
        private readonly IMapper _mapper;

        public DetailBookingService(IDetailBookingRepository DetailBookingRepository, IMapper mapper)
        {
            _DetailBookingRepository = DetailBookingRepository;
            _mapper = mapper;
        }

        public async Task<DetailBookingModel> GetDetailBookingAsync(int id)
        {
            var respuesta = await _DetailBookingRepository.GetByIdAsync(id);
            return _mapper.Map<DetailBookingModel>(respuesta);
        }
        
        public async Task<IEnumerable<FeactureBookingModel>> GetByIdBookingAsync(int id)
        {
            var respuesta = await _DetailBookingRepository.GetByIdBookingAsync(id);
            return _mapper.Map<IEnumerable<FeactureBookingModel>>(respuesta);
        }

        public async Task<DetailBookingModel> CreateDetailBookingAsync(DetailBookingModel DetailBookingDto)
        {
            DetailBooking respuesta = new();
            respuesta = _mapper.Map<DetailBooking>(DetailBookingDto);
            await _DetailBookingRepository.AddAsync(respuesta);
            return _mapper.Map<DetailBookingModel>(respuesta);
        }

        public async Task<IEnumerable<DetailBookingModel>> GetAllDetailBookings()
        {
            var list = await _DetailBookingRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<DetailBookingModel>>(list);
        }

        public async Task<DetailBookingModel> UpdateDetailBooking(DetailBookingModel param)
        {
            Domain.Entities.DetailBooking respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.DetailBooking>(param);
            await _DetailBookingRepository.UpdateAsync(respuesta);
            return _mapper.Map<DetailBookingModel>(respuesta);
        }

        public void DeleteDetailBooking(int id)
        {
            _DetailBookingRepository.DeleteAsync(id);
        }
    }
}
