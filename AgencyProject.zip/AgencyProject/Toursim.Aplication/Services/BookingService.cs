﻿using AutoMapper;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Domain.Entities;
using Toursim.Domain.Interfaces;
using System.Threading.Tasks;
using Toursim.Domain.Interfaces.Booking;
using Toursim.Infrastructure.Repositories;
using System.Collections.Generic;

namespace Toursim.Application.Services
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepository;
        private readonly IMapper _mapper;

        public BookingService(IBookingRepository bookingRepository, IMapper mapper)
        {
            _bookingRepository = bookingRepository;
            _mapper = mapper;
        }

        public async Task<BookingModel> GetBookingAsync(int id)
        {
            Domain.Entities.Booking respuesta = new();
            respuesta = await _bookingRepository.GetByIdAsync(id);
            return _mapper.Map<BookingModel>(respuesta);
        }

        public async Task<IEnumerable<BookingDetailModel>> GetBookingByHotelAsync(int idHotel)
        {
            var respuesta = await _bookingRepository.GetByIdHotelAsync(idHotel);
            return _mapper.Map<IEnumerable<BookingDetailModel>>(respuesta);
        }

        public async Task<BookingModel> CreateBookingAsync(BookingModel bookingDto)
        {
            Domain.Entities.Booking respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.Booking>(bookingDto);
            await _bookingRepository.AddAsync(respuesta);
            return _mapper.Map<BookingModel>(respuesta);
        }

        public async Task<IEnumerable<BookingModel>> GetAllBookings()
        {
            var list = await _bookingRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<BookingModel>>(list);
        }

        public async Task<BookingModel> UpdateBooking(BookingModel param)
        {
            Domain.Entities.Booking respuesta = new();
            respuesta = _mapper.Map<Domain.Entities.Booking>(param);
            await _bookingRepository.UpdateAsync(respuesta);
            return _mapper.Map<BookingModel>(respuesta);
        }

        public void DeleteBooking(int id)
        {
            _bookingRepository.DeleteAsync(id);
        }
    }
}

