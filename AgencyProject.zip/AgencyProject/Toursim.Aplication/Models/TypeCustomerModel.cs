﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Models
{
    public class TypeCustomerModel
    {
        public int TypeCustomer1 { get; set; }

        public string NameCustomer { get; set; }

        public virtual ICollection<CustomerModel> Customers { get; set; } = new List<CustomerModel>();
    }
}
