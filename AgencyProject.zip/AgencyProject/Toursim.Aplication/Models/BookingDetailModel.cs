﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Models
{
    public class BookingDetailModel
    {
        public int BookingId { get; set; }
        public int IdHotel { get; set; }
        public string HotelName { get; set; } = string.Empty;
        public string GuestsNumber { get; set; } = string.Empty;
        public int IdCustomer { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public decimal Amount { get; set; }
        public int TotalPerson { get; set; }
        public string Status { get; set; } = string.Empty;
        public int TypeCustomer { get; set; }

    }
}
