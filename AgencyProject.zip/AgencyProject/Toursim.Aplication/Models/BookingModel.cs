﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Models
{
    public class BookingModel
    {
        public int IdBooking { get; set; }

        public int IdCustomer { get; set; }

        public int IdHotel { get; set; }

        public decimal Amount { get; set; }

        public int TotalPerson { get; set; }

        public DateTime DateInicial { get; set; }

        public DateTime DateEnd { get; set; }

        public string Status { get; set; }
    }
}
