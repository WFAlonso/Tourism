﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Models
{
    public class TypeDocumentModel
    {
        public int TypeDocument1 { get; set; }

        public string NameDocument { get; set; }

        public virtual ICollection<CustomerModel> Customers { get; set; } = new List<CustomerModel>();
    }
}
