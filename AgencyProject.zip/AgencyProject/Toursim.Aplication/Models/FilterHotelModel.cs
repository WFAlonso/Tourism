﻿namespace Toursim.Application.Models
{
    public class FilterHotelModel
    {
        public string InDate { get; set; } = string.Empty;
        public string OutDate { get; set; } = string.Empty;
        public string CountRooms { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;

    }
}
