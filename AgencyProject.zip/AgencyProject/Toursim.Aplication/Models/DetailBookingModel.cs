﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Models
{
    public class DetailBookingModel
    {
        public int IdDetail { get; set; }

        public int IdBooking { get; set; }

        public int IdHotelRoom { get; set; }

        public int IdCustomer { get; set; }
    }
}
