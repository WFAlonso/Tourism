﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Models
{
    public class CustomerModel
    {
        public int IdCustomer { get; set; }

        public int TypeDocument { get; set; }

        public decimal NumDocument { get; set; }

        public string Name { get; set; }

        public string Lastname { get; set; }

        public DateTime? Birthday { get; set; }

        public string Gender { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public int TypeCustomer { get; set; }
    }
}
