﻿namespace Toursim.Application.Models
{
    public class MailModel
    {
        public string To { get; set; }
        public string Subject { get; set; }
        public object txt { get; set; }
    }
}