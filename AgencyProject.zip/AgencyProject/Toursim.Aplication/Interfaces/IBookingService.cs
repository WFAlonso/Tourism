﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toursim.Domain.Entities;
using System.Collections.Generic;
using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface IBookingService
    {
        Task<BookingModel> GetBookingAsync(int id);
        Task<IEnumerable<BookingDetailModel>> GetBookingByHotelAsync(int idHotel);        
        Task<BookingModel> CreateBookingAsync(BookingModel param);
        Task<IEnumerable<BookingModel>> GetAllBookings();
        Task<BookingModel> UpdateBooking(BookingModel param);
        void DeleteBooking(int id);
    }
}
