﻿using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface IHotelRoomService
    {
        Task<HotelRoomModel> GetHotelRoomAsync(int id);
        Task<HotelRoomModel> CreateHotelRoomAsync(HotelRoomModel param);
        Task<IEnumerable<HotelRoomModel>> GetAllHotelRooms();
        Task<HotelRoomModel> UpdateHotelRoom(int id, HotelRoomModel param);
        void DeleteHotelRoom(int id);
    }
}
