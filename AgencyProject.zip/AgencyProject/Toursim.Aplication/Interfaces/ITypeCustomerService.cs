﻿using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface ITypeCustomerService
    {
        Task<TypeCustomerModel> GetTypeCustomerAsync(int id);
        Task<TypeCustomerModel> CreateTypeCustomerAsync(TypeCustomerModel param);
        Task<IEnumerable<TypeCustomerModel>> GetAllTypeCustomers();
         Task<TypeCustomerModel> UpdateTypeCustomer(TypeCustomerModel param);
        void DeleteTypeCustomer(int id);
    }
}
