﻿using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface ITypeDocumentService
    {
        Task<TypeDocumentModel> GetTypeDocumentAsync(int id);
        Task<TypeDocumentModel> CreateTypeDocumentAsync(TypeDocumentModel param);
        Task<IEnumerable<TypeDocumentModel>> GetAllTypeDocuments();
        Task<TypeDocumentModel> UpdateTypeDocument(TypeDocumentModel param);
        void DeleteTypeDocument(int id);
    }
}
