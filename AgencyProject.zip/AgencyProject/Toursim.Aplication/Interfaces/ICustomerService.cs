﻿using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface ICustomerService
    {
        Task<CustomerModel> GetCustomerAsync(int id);
        Task<CustomerModel> CreateCustomerAsync(CustomerModel param);
        Task<IEnumerable<CustomerModel>> GetAllCustomers();
        Task<CustomerModel> UpdateCustomerAsync(CustomerModel param);
        void DeleteCustomer(int id);
    }
}
