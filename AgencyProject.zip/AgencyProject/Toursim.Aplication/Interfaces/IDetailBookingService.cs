﻿using Toursim.Application.Models;
using Toursim.Domain.Entities;

namespace Toursim.Application.Interfaces
{
    public interface IDetailBookingService
    {
        Task<DetailBookingModel> GetDetailBookingAsync(int id);
        Task<DetailBookingModel> CreateDetailBookingAsync(DetailBookingModel param);
        Task<IEnumerable<FeactureBookingModel>> GetByIdBookingAsync(int id);
        Task<IEnumerable<DetailBookingModel>> GetAllDetailBookings();
        Task<DetailBookingModel> UpdateDetailBooking(DetailBookingModel param);
        void DeleteDetailBooking(int id);
    }
}
