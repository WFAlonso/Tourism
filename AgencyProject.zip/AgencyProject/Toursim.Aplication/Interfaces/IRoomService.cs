﻿using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface IRoomService
    {
        Task<RoomModel> GetRoomAsync(int id);
        Task<RoomModel> CreateRoomAsync(RoomModel param);
        Task<IEnumerable<RoomModel>> GetAllRooms();
        Task<RoomModel> UpdateRoom(RoomModel param);
        void DeleteRoom(int id);
    }
}
