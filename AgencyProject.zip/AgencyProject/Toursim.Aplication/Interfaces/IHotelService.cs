﻿using Toursim.Application.Models;

namespace Toursim.Application.Interfaces
{
    public interface IHotelService
    {
        Task<HotelModel> GetHotelAsync(int id);
        Task<HotelModel> CreateHotelAsync(HotelModel param);
        Task<IEnumerable<HotelModel>> GetAllHotels(TypeRegister type);
        Task<IEnumerable<HotelModel>> GetHotelsByStateAsync(bool state);
        Task<IEnumerable<HotelModel>> GetHotelByFilter(FilterHotelModel filter);         
        Task<HotelModel> UpdateHotel(HotelModel param);
        void DeleteHotel(int id);
    }
}
