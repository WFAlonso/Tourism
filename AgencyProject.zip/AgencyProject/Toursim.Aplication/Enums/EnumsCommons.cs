﻿namespace Toursim.Application
{
    public enum TypeRegister
    {
        All = 0,
        Top,
        NoTop
    }
}
