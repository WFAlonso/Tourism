﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toursim.Application.Dtos
{
    public class BookingDetailDto
    {
        public int BookingId { get; set; }
        public string HotelName { get; set; }
        public string RoomNumber { get; set; }
        public string GuestName { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public decimal Amount { get; set; }
    }
}
