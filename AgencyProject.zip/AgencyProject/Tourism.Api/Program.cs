using Microsoft.EntityFrameworkCore;
using Toursim.Infrastructure.Data;
using Toursim.Infrastructure.Repositories;
using Toursim.Domain.Interfaces;
using Tourism.Api.Mappings;
using Toursim.Application.Services;
using Toursim.Infrastructure.Mappings;
using Toursim.Application.Interfaces;
using Toursim.Domain.Interfaces.Booking;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddDbContext<TourismDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddTransient<IEmailService>(provider =>
    new SmtpEmailService("smtp.correo.com", 587, "no-reply@example.com", "user", "pass"));

builder.Services.AddAutoMapper(typeof(ApiMappingProfile).Assembly);
builder.Services.AddAutoMapper(typeof(InfraestructureMappingProfile));

builder.Services.AddScoped<IBookingService, BookingService>();
builder.Services.AddScoped<IBookingRepository, BookingRepository>();
builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<ICustomerRepository, CustomerRepository>();
builder.Services.AddScoped<IDetailBookingService, DetailBookingService>();
builder.Services.AddScoped<IDetailBookingRepository, DetailBookingRepository>();
builder.Services.AddScoped<IHotelService, HotelService>();
builder.Services.AddScoped<IHotelRepository, HotelRepository>();
builder.Services.AddScoped<IHotelRoomService, HotelRoomService>();
builder.Services.AddScoped<IHotelRoomRepository, HotelRoomRepository>();
builder.Services.AddScoped<IRoomService, RoomService>();
builder.Services.AddScoped<IRoomRepository, RoomRepository>();
builder.Services.AddScoped<ITypeCustomerService, TypeCustomerService>();
builder.Services.AddScoped<ITypeCustomerRepository, TypeCustomerRepository>();
builder.Services.AddScoped<ITypeDocumentService, TypeDocumentService>();
builder.Services.AddScoped<ITypeDocumentRepository, TypeDocumentRepository>();


builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(); 
builder.Services.AddCors(); 

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.MapControllers();

app.Run();