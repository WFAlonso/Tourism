﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HotelController : Controller
    {
        private readonly IHotelService _hotelService;
        private readonly IMapper _mapper;
        public HotelController(IHotelService hotelService
            , IMapper mapper)
        {
            _hotelService = hotelService;
            _mapper = mapper;
        }
        /// <summary>
        /// GEt a hotel by id
        /// </summary>
        /// <param name="id">id of hotel</param>
        /// <returns>List od hotels</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetHotel(int id)
        {
            var hotel = await _hotelService.GetHotelAsync(id);
            if (hotel == null) return NotFound();
            return Ok(hotel);
        }
        /// <summary>
        /// Get a list of hotels based on preference
        /// </summary>
        /// <param name="type">TypeRegister: 0 -> all; 1-> favorites ; 2 -> no favrites</param>
        /// <returns>List od hotels</returns>
        [HttpGet("type/{type}")]
        public async Task<IActionResult> GetAllHotel(TypeRegister type)
        {
            IEnumerable<HotelModel> hotel = await _hotelService.GetAllHotels(type);
            if (hotel == null) return NotFound();
            return Ok(hotel);
        }
        /// <summary>
        /// Get hotels with a state specific
        /// </summary>
        /// <param name="enabled">state to search</param>
        /// <returns>List od hotels</returns>
        [HttpGet("Enabled/{enabled}")]
        public async Task<IActionResult> GetEnabledHotel(bool enabled)
        {
            IEnumerable<HotelModel> hotel = await _hotelService.GetHotelsByStateAsync(enabled);
            if (hotel == null || !hotel.Any()) return NotFound();
            return Ok(hotel);
        }

        /// <summary>
        /// Get a list of hotels by filter
        /// </summary>
        /// <param name="filter">fiter of search</param>
        /// <returns>List od hotels</returns>
        [HttpPost("Filter")]
        public async Task<IActionResult> GetHotelByFilter([FromBody] FilterHotelModel filter)
        {
            IEnumerable<HotelModel> hotel = await _hotelService.GetHotelByFilter(filter);
            if (hotel == null) return NotFound();
            return Ok(hotel);
        }
        /// <summary>
        /// Create a hotel 
        /// </summary>
        /// <param name="hotelDto">object will be create</param>
        /// <returns>entitie hotel</returns>
        [HttpPost]
        public async Task<IActionResult> CreateHotel([FromBody] HotelModel hotelDto)
        {
            var hotel = await _hotelService.CreateHotelAsync(hotelDto);
            return CreatedAtAction(nameof(GetHotel), new { id = hotel.IdHotel }, hotel);
        }
        /// <summary>
        /// add or remove of favorite list 
        /// </summary>
        /// <param name="id">id hotel to be altered</param>
        /// <returns>not specified</returns>
        [HttpPut("SwitchFavorite/{id}")]
        public async Task<ActionResult> AddToFavoritList(int id)
        {
            var hotel = await _hotelService.GetHotelAsync(id);
            if (hotel == null)
            {
                return NotFound();
            }
            hotel.Favorite = !hotel.Favorite;
            await _hotelService.UpdateHotel(hotel);
            return NoContent();
        }
        /// <summary>
        /// Enabled or disabled a hotel 
        /// </summary>
        /// <param name="id">id hotel to be altered</param>
        /// <returns>not specified</returns>
        [HttpPut("SwitchActive/{id}")]
        public async Task<ActionResult> SwitchActiveHotel(int id)
        {
            var hotel = await _hotelService.GetHotelAsync(id);
            if (hotel == null)
            {
                return NotFound();
            }
            hotel.Active = !hotel.Active;
            await _hotelService.UpdateHotel(hotel);
            return NoContent();
        }
        /// <summary>
        /// Update a Hotel 
        /// </summary>
        /// <param name="id">id hotel to be altered</param>
        /// <param name="hotel">object to update</param>
        /// <returns>not specified</returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] HotelModel hotel)
        {
            if (id != hotel.IdHotel)
            {
                return BadRequest();
            }
            var existingHotel = await _hotelService.GetHotelAsync(id);
            if (existingHotel == null)
            {
                return NotFound();
            }
            await _hotelService.UpdateHotel(hotel);
            return NoContent();
        }
        /// <summary>
        /// Hotel to be deleted
        /// </summary>
        /// <param name="id">id Hotel will be deleted.</param>
        /// <returns>not specified</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var hotel = await _hotelService.GetHotelAsync(id);
            if (hotel == null)
            {
                return NotFound();
            }
            _hotelService.DeleteHotel(id);
            return NoContent();
        }
    }
}
