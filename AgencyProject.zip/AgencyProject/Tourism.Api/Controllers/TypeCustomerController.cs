﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TypeCustomerController : Controller
    {
        private readonly ITypeCustomerService _typeCustomerService;
        private readonly IMapper _mapper;
        public TypeCustomerController(ITypeCustomerService typeCustomerService
            , IMapper mapper)
        {
            _typeCustomerService = typeCustomerService;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetHotel(int id)
        {
            var TypeCustomer = await _typeCustomerService.GetTypeCustomerAsync(id);
            if (TypeCustomer == null) return NotFound();
            return Ok(TypeCustomer);
        }

        [HttpPost]
        public async Task<IActionResult> CreateHotel([FromBody] TypeCustomerModel typeCustomerDto)
        {
            var typeCustomer = await _typeCustomerService.CreateTypeCustomerAsync(typeCustomerDto);
            return CreatedAtAction(nameof(GetHotel), new { id = typeCustomerDto.TypeCustomer1 }, typeCustomerDto);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] TypeCustomerModel typeCustomer)
        {
            if (id != typeCustomer.TypeCustomer1)
            {
                return BadRequest();
            }
            var existingHotel = await _typeCustomerService.GetTypeCustomerAsync(id);
            if (existingHotel == null)
            {
                return NotFound();
            }
            await _typeCustomerService.UpdateTypeCustomer(typeCustomer);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var typeCustomer = await _typeCustomerService.GetTypeCustomerAsync(id);
            if (typeCustomer == null)
            {
                return NotFound();
            }
            _typeCustomerService.DeleteTypeCustomer(id);
            return NoContent();
        }
    }
}
