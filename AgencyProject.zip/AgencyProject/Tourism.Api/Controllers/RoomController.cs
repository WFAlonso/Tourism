﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Application.Services;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoomController : Controller
    {
        private readonly IRoomService _roomService;
        private readonly IMapper _mapper;
        public RoomController(IRoomService roomService
            , IMapper mapper)
        {
            _roomService = roomService;
            _mapper = mapper;
        }
        /// <summary>
        /// Get information of room
        /// </summary>
        /// <param name="id">id room to search</param>
        /// <returns>entitie room</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRoom(int id)
        {
            var hotelRoom = await _roomService.GetRoomAsync(id);
            if (hotelRoom == null) return NotFound();
            return Ok(hotelRoom);
        }
        /// <summary>
        /// Create a room 
        /// </summary>
        /// <param name="hotelDto">object will be create</param>
        /// <returns>entitie room</returns>
        [HttpPost]
        public async Task<IActionResult> CreateRoom([FromBody] RoomModel room)
        {
            var Room = await _roomService.CreateRoomAsync(room);
            return CreatedAtAction(nameof(GetRoom), new { id = room.IdRoom }, room);
        }
        /// <summary>
        /// Enabled or disabled a room 
        /// </summary>
        /// <param name="id">id room to be altered</param>
        /// <returns>not specified</returns>
        [HttpPut("SwitchActive/{id}")]
        public async Task<ActionResult> SwitchActiveRoomAsync(int id)
        {
            var Room = await _roomService.GetRoomAsync(id);
            if (Room == null)
            {
                return NotFound();
            }
            Room.Active = !Room.Active;
            await _roomService.UpdateRoom(Room);
            return NoContent();
        }
        /// <summary>
        /// Update a room 
        /// </summary>
        /// <param name="id">id room to be altered</param>
        /// <param name="hotel">object to update</param>
        /// <returns>not specified</returns>
        [HttpPut]
        public async Task<ActionResult> UpdateAsync([FromBody] RoomModel room)
        {
                var result  = await _roomService.UpdateRoom(room);
                return Ok(result);
        }
        /// <summary>
        /// Room to be deleted
        /// </summary>
        /// <param name="id">id room will be deleted.</param>
        /// <returns>not specified</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var hotelRoom = await _roomService.GetRoomAsync(id);
            if (hotelRoom == null)
            {
                return NotFound();
            }
            _roomService.DeleteRoom(id);
            return NoContent();
        }
    }
}
