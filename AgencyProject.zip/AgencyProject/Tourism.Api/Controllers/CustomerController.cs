﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Application.Services;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : Controller
    {
        private readonly ICustomerService _CustomerService;
        private readonly IMapper _mapper;
        public CustomerController(ICustomerService CustomerService
            , IMapper mapper)
        {
            _CustomerService = CustomerService;
            _mapper = mapper;
        }


        /// <summary>
        /// Get a customer by id
        /// </summary>
        /// <param name="id">Code of customer</param>
        /// <returns>Entitie of customer</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCustomer(int id)
        {
            var Customer = await _CustomerService.GetCustomerAsync(id);
            if (Customer == null) return NotFound();
            return Ok(Customer);
        }

        /// <summary>
        /// Create a customer
        /// </summary>
        /// <param name="hotelDto">client object to be created</param>
        /// <returns>entitie customer</returns>
        [HttpPost]
        public async Task<IActionResult> CreateHotel([FromBody] CustomerModel hotelDto)
        {
            var Customer = await _CustomerService.CreateCustomerAsync(hotelDto);
            return CreatedAtAction(nameof(GetCustomer), new { id = Customer.IdCustomer }, Customer);
        }

        /// <summary>
        /// Update a customer
        /// </summary>
        /// <param name="id">id of customer</param>
        /// <param name="Customer">object with modifications</param>
        /// <returns>no specification</returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] CustomerModel Customer)
        {
            if (id != Customer.IdCustomer)
            {
                return BadRequest();
            }
            var existingCustomer = await _CustomerService.GetCustomerAsync(id);
            if (existingCustomer == null)
            {
                return NotFound();
            }
            await _CustomerService.UpdateCustomerAsync(Customer);
            return NoContent();
        }
        /// <summary>
        /// customer to be removed
        /// </summary>
        /// <param name="id">id of customer to be removed</param>
        /// <returns>no specification</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var Customer = await _CustomerService.GetCustomerAsync(id);
            if (Customer == null)
            {
                return NotFound();
            }
            _CustomerService.DeleteCustomer(id);
            return NoContent();
        }
    }
}
