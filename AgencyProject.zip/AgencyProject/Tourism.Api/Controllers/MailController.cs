﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MailController : ControllerBase
    {
        private readonly IEmailService _emailService;

        public MailController(IEmailService emailService)
        {
            _emailService = emailService;
        }
        /// <summary>
        /// metod to send email
        /// </summary>
        /// <param name="mailModel">object with detail of messege</param>
        /// <returns>not specified</returns>
        [HttpPost]
        public async Task<ActionResult> SendMailAsync([FromBody] MailModel mailModel)
        {
            await _emailService.SendEmailAsync(
                mailModel.To,
                mailModel.Subject,
                $"{mailModel.txt}");

            return Ok();
        }
    }
}