﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DetailBookingController : Controller
    {
        private readonly IDetailBookingService _DetailBookingService;
        private readonly IMapper _mapper;
        public DetailBookingController(IDetailBookingService DetailBookingService
            , IMapper mapper)
        {
            _DetailBookingService = DetailBookingService;
            _mapper = mapper;
        }
        /// <summary>
        /// Get detail booking by id booking
        /// </summary>
        /// <param name="idBooking">id of booking</param>
        /// <returns>List of bookings</returns>
        [HttpGet("{idBooking}")]
        public async Task<IActionResult> GetDetailBooking(int idBooking)
        {
            var DetailBooking = await _DetailBookingService.GetByIdBookingAsync(idBooking);
            if (DetailBooking == null) return NotFound();
            return Ok(DetailBooking);
        }
        /// <summary>
        /// Create a booking
        /// </summary>
        /// <param name="detailBooking">reserve object to create</param>
        /// <returns>Entitie booking</returns>
        [HttpPost]
        public async Task<IActionResult> CreateDetailBooking([FromBody] DetailBookingModel detailBooking)
        {
            var DetailBooking = await _DetailBookingService.CreateDetailBookingAsync(detailBooking);
            return CreatedAtAction(nameof(GetDetailBooking), new { id = DetailBooking.IdBooking }, detailBooking);
        }
        /// <summary>
        /// update a head booking
        /// </summary>
        /// <param name="id">id booking to be altered</param>
        /// <param name="DetailBooking">reserve object to create</param>
        /// <returns>not specified</returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] DetailBookingModel DetailBooking)
        {
            if (id != DetailBooking.IdBooking)
            {
                return BadRequest();
            }
            var existingHotel = await _DetailBookingService.GetDetailBookingAsync(id);
            if (existingHotel == null)
            {
                return NotFound();
            }
            await _DetailBookingService.UpdateDetailBooking(DetailBooking);
            return NoContent();
        }
        /// <summary>
        /// Booking to be deleted
        /// </summary>
        /// <param name="id">id booking will be deleted.</param>
        /// <returns>not specified</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var DetailBooking = await _DetailBookingService.GetDetailBookingAsync(id);
            if (DetailBooking == null)
            {
                return NotFound();
            }
            _DetailBookingService.DeleteDetailBooking(id);
            return NoContent();
        }
    }
}
