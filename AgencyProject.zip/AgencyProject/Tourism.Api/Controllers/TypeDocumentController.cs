﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Application.Services;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TypeDocumentController : Controller
    {
        private readonly ITypeDocumentService _typeDocumentService;
        private readonly IMapper _mapper;
        public TypeDocumentController(ITypeDocumentService typeDocumentService
            , IMapper mapper)
        {
            _typeDocumentService = typeDocumentService;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetHotel(int id)
        {
            var typeDocument = await _typeDocumentService.GetTypeDocumentAsync(id);
            if (typeDocument == null) return NotFound();
            return Ok(typeDocument);
        }

        [HttpPost]
        public async Task<IActionResult> CreateHotel([FromBody] TypeDocumentModel typeDocument)
        {
            var TypeDocument = await _typeDocumentService.CreateTypeDocumentAsync(typeDocument);
            return CreatedAtAction(nameof(GetHotel), new { id = typeDocument.TypeDocument1 }, typeDocument);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] TypeDocumentModel typeDocument)
        {
            if (id != typeDocument.TypeDocument1)
            {
                return BadRequest();
            }
            var existingHotel = await _typeDocumentService.GetTypeDocumentAsync(id);
            if (existingHotel == null)
            {
                return NotFound();
            }
            await _typeDocumentService.UpdateTypeDocument(typeDocument);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var typeDocument = await _typeDocumentService.GetTypeDocumentAsync(id);
            if (typeDocument == null)
            {
                return NotFound();
            }
            _typeDocumentService.DeleteTypeDocument(id);
            return NoContent();
        }
    }
}
