﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Application.Services;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingController : Controller
    {
        private readonly IBookingService _BookingService;
        private readonly IMapper _mapper;
        public BookingController(IBookingService bookingService
            , IMapper mapper)
        {
            _BookingService = bookingService;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBookingById(int id)
        {
            var hotel = await _BookingService.GetBookingAsync(id);
            if (hotel == null) return NotFound();
            return Ok(hotel);
        }
        /// <summary>
        /// Get Booking by id hotel
        /// </summary>
        /// <param name="idHotel">code of hotel</param>
        /// <returns>Liust of head bookings</returns>
        [HttpGet("Hotel/{idHotel}")]
        public async Task<IActionResult> GetBookingByHotel(int idHotel)
        {
            var hotel = await _BookingService.GetBookingByHotelAsync(idHotel);
            if (hotel == null) return NotFound();
            return Ok(hotel);
        }

        [HttpPost]
        public async Task<IActionResult> AddBooking([FromBody] BookingModel hotelDto)
        {
            var hotel = await _BookingService.CreateBookingAsync(hotelDto);
            return CreatedAtAction(nameof(GetBookingById), new { id = hotel.IdBooking }, hotel);
        }


        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] BookingModel Booking)
        {
            if (id != Booking.IdBooking)
            {
                return BadRequest();
            }
            var existingBooking = await _BookingService.GetBookingAsync(id);
            if (existingBooking == null)
            {
                return NotFound();
            }
            await _BookingService.UpdateBooking(Booking);
            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var booking = await _BookingService.GetBookingAsync(id);
            if (booking == null)
            {
                return NotFound();
            }
            _BookingService.DeleteBooking(id);
            return NoContent();
        }
    }
}
