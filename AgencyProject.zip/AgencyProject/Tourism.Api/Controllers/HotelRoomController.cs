﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Toursim.Application.Interfaces;
using Toursim.Application.Models;
using Toursim.Application.Services;

namespace Tourism.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HotelRoomController : Controller
    {
        private readonly IHotelRoomService _hotelRoomService;
        private readonly IMapper _mapper;
        public HotelRoomController(IHotelRoomService hotelRoomService
            , IMapper mapper)
        {
            _hotelRoomService = hotelRoomService;
            _mapper = mapper;
        }
        /// <summary>
        /// Get the room by id
        /// </summary>
        /// <param name="id">id to search</param>
        /// <returns>detail of a room of hotel</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetHotelRoom(int id)
        {
            var hotelRoom = await _hotelRoomService.GetHotelRoomAsync(id);
            if (hotelRoom == null) return NotFound();
            return Ok(hotelRoom);
        }
        /// <summary>
        /// Create a HotelRoom
        /// </summary>
        /// <param name="hotelRoom">objet to be created</param>
        /// <returns>detail of a room of hotel</returns>
        [HttpPost]
        public async Task<IActionResult> SetHotelRoom([FromBody] HotelRoomModel hotelRoom)
        {
            var HotelRoom = await _hotelRoomService.CreateHotelRoomAsync(hotelRoom);
            return CreatedAtAction(nameof(GetHotelRoom), new { id = hotelRoom.IdRoom }, hotelRoom);
        }
        /// <summary>
        /// Enabled or disabled a hotel 
        /// </summary>
        /// <param name="id">id room of hotel to be altered</param>
        /// <returns>not specified</returns>
        [HttpPut("SwitchActive/{id}")]
        public async Task<ActionResult> SwitchActiveHotelRoomAsync(int id)
        {
            var hotelRoom = await _hotelRoomService.GetHotelRoomAsync(id);
            if (hotelRoom == null)
            {
                return NotFound();
            }
            hotelRoom.Active = !hotelRoom.Active;
            await _hotelRoomService.UpdateHotelRoom(id, hotelRoom);
            return NoContent();
        }
        /// <summary>
        /// update a room of hote
        /// </summary>
        /// <param name="id">id room of hotel to be altered</param>
        /// <param name="hotelRoom">objet to be created</param>
        /// <returns>not specified</returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAsync(int id, [FromBody] HotelRoomModel hotelRoom)
        {
            var existingHotelRoom = await _hotelRoomService.GetHotelRoomAsync(id);
            if (existingHotelRoom == null)
            {
                return NotFound();
            }
            await _hotelRoomService.UpdateHotelRoom(id, hotelRoom);
            return NoContent();
        }
        /// <summary>
        /// room of Hotel to be deleted
        /// </summary>
        /// <param name="id">id of room of Hotel will be deleted.</param>
        /// <returns>not specified</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
            var hotelRoom = await _hotelRoomService.GetHotelRoomAsync(id);
            if (hotelRoom == null)
            {
                return NotFound();
            }
            _hotelRoomService.DeleteHotelRoom(id);
            return NoContent();
        }
    }
}
