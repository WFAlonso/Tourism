﻿using AutoMapper;
using Toursim.Application.Models;
using Toursim.Domain.Entities;

namespace Tourism.Api.Mappings
{
    public class ApiMappingProfile : Profile
    {
        public ApiMappingProfile()
        {
            CreateMap<Booking, BookingModel>();
            CreateMap<BookingModel, Booking>();
            CreateMap<Customer, CustomerModel>();
            CreateMap<CustomerModel, Customer>();
            CreateMap<DetailBooking, DetailBookingModel>();
            CreateMap<DetailBookingModel, DetailBooking>();
            CreateMap<Hotel, HotelModel>();
            CreateMap<HotelModel, Hotel>();
            CreateMap<HotelRoom, HotelRoomModel>();
            CreateMap<HotelRoomModel, HotelRoom>();
            CreateMap<Room, RoomModel>();
            CreateMap<RoomModel, Room>();
            CreateMap<TypeCustomer, TypeCustomerModel>();
            CreateMap<TypeCustomerModel, TypeCustomer >();
            CreateMap<TypeDocument, TypeDocumentModel>();
            CreateMap<TypeDocumentModel, TypeDocument>();
            CreateMap<BookingDetail, BookingDetailModel>();
            CreateMap<BookingDetailModel, BookingDetail>();
            CreateMap<FeactureBooking, FeactureBookingModel>();
            CreateMap<FeactureBookingModel, FeactureBooking>();
            
        }
    }
}